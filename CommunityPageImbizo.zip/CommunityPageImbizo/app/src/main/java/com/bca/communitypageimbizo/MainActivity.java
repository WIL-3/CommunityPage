package com.bca.communitypageimbizo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    //Variables initialized for buttons, Text Edits and Firebase Authentication.
    public Button buttonLogin;
    public EditText etUsername, etPassword;
    private TextView forgot_password, create_account_tv;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Getting current firebase instance
        mAuth = FirebaseAuth.getInstance();
        //currentUser = mAuth.getCurrentUser();

        //Setting Text Edit variables with the ones in the UI.
        etUsername = findViewById(R.id.login_email_edtx);
        etPassword = findViewById(R.id.login_password_edtx);

        //Setting login button with the ones in the UI.
        buttonLogin = findViewById(R.id.login_btn);

        //Setting Text View variables with the ones in the UI
        forgot_password = findViewById(R.id.forgot_password_tv);
        create_account_tv = findViewById(R.id.login_create_new_account_tv);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Login();
            }
        });

        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, MainForgotPassword.class);
                startActivity(intent);
                finish();
            }
        });

        create_account_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, MainSignup.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void Login() { //start of Login() Method

        //getting Text from edit text fields
        String email = etUsername.getText().toString();
        String password = etPassword.getText().toString();


        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Sign in success, update UI with the signed-in user's information
                    Toast.makeText(MainActivity.this, "Success",
                            Toast.LENGTH_SHORT).show();

                    currentUser = mAuth.getCurrentUser();
                    Intent i = new Intent(MainActivity.this, NavDrawerActivity.class);
                    startActivity(i);

                } else {
                    // If sign in fails, display a message to the user.
                    currentUser = null;
                    Toast.makeText(MainActivity.this, "Authentication failed.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

    }//end of Login() method
}